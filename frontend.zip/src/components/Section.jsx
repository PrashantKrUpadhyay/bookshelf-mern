import React from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const Section = ({data}) => { 
  const { id } = useParams(); // Get the book ID from the URL
  
  const navigate = useNavigate();
console.log(data);


const deleteBook = async (id) => {
 
  try {
    const response = await axios.delete(`http://localhost:1000/api/v1/deleteBook/${id}`);
    if (response.status === 201) {
      alert('Book deleted successfully');
    }
  } catch (error) {
    console.error('Error deleting the book:', error);
    alert('Failed to delete the book. Please try again.');
  }
};
// const handleDelete = async (id) => {
//   try {
//       // await axios.delete(`/deleteBook/${id}`);
//       // alert('Book deleted successfully');
//       // navigate('/home'); // Redirect back to home or book list after deleting
//       const response = await axios.delete(`/deleteBook/${id}`);
//       if (response.status === 201) {
//         alert('Book deleted successfully');
//       }
//   } catch (error) {
//       // console.error('Error deleting book', error);
//       console.error('Error deleting the book:', error);
//       alert('Failed to delete the book. Please try again.');
//   }
// };
const handleDelete = async (id) => {
  console.log(id)
  if (window.confirm('Are you sure you want to delete this book?')) {
    await deleteBook(id);
   // navigate('/books'); // Redirect to the homepage after deletion
  }
};
  return (
   
    
    <div className="section_class d-flex flex-wrap ">
        {data && data.map((item, index) => (
            <div className="grid" key={item.id}>
         { console.log(item._id) }

                <div> <img  className="img-fluid " src={item.image} alt="/" /> </div>
        <h6 style={{ fontSize:"15px"}} className="text-white my-1 px-2">{item.bookname.slice(0,20)}...</h6>
        <b style={{ fontSize:"30px",}} className="text-white px-2  ">Rs.{item.price}</b>
        <div className="section_button"> 
        <button className="btn btn-danger" onClick={()=> handleDelete(item?._id)} >Delete</button>
        </div>
        
        </div>
        ))}
       
    </div>
  );
}

export default Section;
