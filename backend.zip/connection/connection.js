const mongoose = require("mongoose");

mongoose.connect("mongodb+srv://prashant:prashant@cluster0.eh6opxr.mongodb.net/store?retryWrites=true&w=majority&appName=Cluster0"
).then((res)=>console.log("Connected to Mongo"));
