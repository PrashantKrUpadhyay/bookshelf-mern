const router = require("express").Router();
const collection = require("../models/loginModel");
const cors =require("cors");

router.get("/",cors(),(req,res)=>{

})


router.post("/",async(req,res)=>{
    const{email,password}=req.body

    try{
        const check=await collection.findOne({email:email})

        if(check){
            res.json("user exist")
        }
        else{
            res.json("user does not exist")
        }

    }
    catch(e){
        res.json("fail")
    }

})



router.post("/signup",async(req,res)=>{
    const{email,password}=req.body

    const data={
        email:email,
        password:password
    }

    try{
        const check=await collection.findOne({email:email})

        if(check){
            res.json("user exist")
        }
        else{
            res.json("user does not exist")
            await collection.insertMany([data])
        }

    }
    catch(e){
        res.json("fail")
    }

})

module.exports = router;